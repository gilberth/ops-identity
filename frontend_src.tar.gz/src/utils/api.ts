const VPS_ENDPOINT = import.meta.env.VITE_VPS_ENDPOINT || 'http://localhost:3000';

export const api = {
    async getAssessments() {
        const response = await fetch(`${VPS_ENDPOINT}/api/assessments`);
        if (!response.ok) throw new Error('Failed to fetch assessments');
        return response.json();
    },

    async getAssessment(id: string) {
        const response = await fetch(`${VPS_ENDPOINT}/api/assessments/${id}`);
        if (!response.ok) throw new Error('Failed to fetch assessment');
        return response.json();
    },

    async getFindings(id: string) {
        const response = await fetch(`${VPS_ENDPOINT}/api/assessments/${id}/findings`);
        if (!response.ok) throw new Error('Failed to fetch findings');
        return response.json();
    },

    async getLogs(id: string) {
        const response = await fetch(`${VPS_ENDPOINT}/api/assessments/${id}/logs`);
        if (!response.ok) throw new Error('Failed to fetch logs');
        return response.json();
    },

    async deleteAssessment(id: string) {
        const response = await fetch(`${VPS_ENDPOINT}/api/assessments/${id}`, {
            method: 'DELETE',
        });
        if (!response.ok) throw new Error('Failed to delete assessment');
        return response.json();
    },

    async resetAssessment(id: string) {
        const response = await fetch(`${VPS_ENDPOINT}/api/assessments/${id}/reset`, {
            method: 'POST',
        });
        if (!response.ok) throw new Error('Failed to reset assessment');
        return response.json();
    },

    async createAssessment(domain: string) {
        const response = await fetch(`${VPS_ENDPOINT}/api/assessments`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ domain }),
        });
        if (!response.ok) throw new Error('Failed to create assessment');
        return response.json();
    },

    getAssessmentData: async (id: string) => {
        const response = await fetch(`${VPS_ENDPOINT}/api/assessments/${id}/data`);
        if (!response.ok) throw new Error('Failed to fetch assessment data');
        return response.json();
    },
};
