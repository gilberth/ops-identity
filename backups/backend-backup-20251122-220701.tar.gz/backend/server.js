import express from 'express';
import cors from 'cors';
import pg from 'pg';
import dotenv from 'dotenv';
import fetch from 'node-fetch'; // Ensure node-fetch is available or use global fetch in Node 18+
import multer from 'multer';
import AdmZip from 'adm-zip';
import fs from 'fs';
import zlib from 'zlib';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Database Configuration
const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:postgres@db:5432/postgres',
});

// Middleware
app.use(cors());
app.use(express.json({ limit: '500mb' }));
app.use(express.text({ limit: '500mb' }));

// Constants
const CATEGORIES = [
  'Users', 'GPOs', 'Computers', 'OUs', 'Groups', 'Domains',
  'Containers', 'ACLs', 'CertServices', 'Meta', 'DCHealth', 'DNS', 'DHCP', 'Security'
];

const MAX_PROMPT = 8000;

// Helper: Log to DB
const timestamp = () => new Date().toISOString();

async function addLog(assessmentId, level, message, categoryId = null) {
  try {
    console.log(`[${timestamp()}] [${level.toUpperCase()}] ${message}`);
    await pool.query(
      'INSERT INTO assessment_logs (assessment_id, level, message, category_id) VALUES ($1, $2, $3, $4)',
      [assessmentId, level, message, categoryId]
    );
  } catch (error) {
    console.error(`[${timestamp()}] ❌ Error logging to DB:`, error.message);
  }
}

// Helper: Sanitize text to remove null bytes and other problematic characters
function sanitizeText(text) {
  if (!text) return text;
  // Remove null bytes (0x00) and other control characters except newlines and tabs
  return text.replace(/\x00/g, '').replace(/[\x01-\x08\x0B-\x0C\x0E-\x1F\x7F]/g, '');
}

// Helper: Get system configuration
async function getConfig(key) {
  try {
    const result = await pool.query('SELECT value FROM system_config WHERE key = $1', [key]);
    return result.rows[0]?.value || null;
  } catch (error) {
    console.error(`[${timestamp()}] Error getting config ${key}:`, error.message);
    return null;
  }
}

// Helper: Set system configuration
async function setConfig(key, value) {
  try {
    await pool.query(
      'INSERT INTO system_config (key, value, updated_at) VALUES ($1, $2, CURRENT_TIMESTAMP) ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = CURRENT_TIMESTAMP',
      [key, value]
    );
    return true;
  } catch (error) {
    console.error(`[${timestamp()}] Error setting config ${key}:`, error.message);
    return false;
  }
}

// Helper: Extract Category Data
function extractCategoryData(jsonData, categoryName) {
  const categoryKey = Object.keys(jsonData).find(key =>
    key.toLowerCase() === categoryName.toLowerCase()
  );

  if (!categoryKey || !jsonData[categoryKey]) return null;

  const categoryData = jsonData[categoryKey];

  if (categoryData.Data) {
    return Array.isArray(categoryData.Data) ? categoryData.Data : [categoryData.Data];
  }
  if (Array.isArray(categoryData)) return categoryData;
  if (typeof categoryData === 'object') return [categoryData];

  return null;
}

// AI Analysis Logic (Ported from Edge Function)
async function analyzeCategory(assessmentId, category, data) {
  try {
    await addLog(assessmentId, 'info', `Starting AI analysis for ${category}...`, category);

    const prompt = buildPrompt(category, data);
    console.log(`[${timestamp()}] [AI] Analyzing ${category} with prompt length: ${prompt.length} chars`);

    let findings = [];

    // Get AI configuration from database
    const provider = (await getConfig('ai_provider')) || 'openai';
    const model = (await getConfig('ai_model')) || 'gpt-4o-mini';
    const apiKey = await getConfig(`${provider}_api_key`) || process.env.OPENAI_API_KEY || process.env.LOVABLE_API_KEY;

    if (!apiKey) {
      await addLog(assessmentId, 'warn', `No API key found for ${provider}. Skipping AI analysis.`, category);
      return [];
    }

    console.log(`[${timestamp()}] [AI] Using ${provider} (${model}) for ${category}`);
    findings = await callAI(prompt, provider, model, apiKey);

    console.log(`[${timestamp()}] [AI] ${category} analysis returned ${findings.length} findings`);
    await addLog(assessmentId, 'info', `AI analysis complete: ${findings.length} findings`, category);

    if (findings.length > 0) {
      for (const f of findings) {
        await pool.query(
          `INSERT INTO findings (
            assessment_id, title, severity, description, recommendation, evidence,
            mitre_attack, cis_control, impact_business, remediation_commands,
            prerequisites, operational_impact, microsoft_docs, current_vs_recommended,
            timeline, affected_count
          )
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)`,
          [
            assessmentId,
            sanitizeText(f.title || 'Security Issue'),
            f.severity || 'medium',
            sanitizeText(f.description || 'No description'),
            sanitizeText(f.recommendation || 'Review finding'),
            JSON.stringify(f.evidence || {}),
            sanitizeText(f.mitre_attack || ''),
            sanitizeText(f.cis_control || ''),
            sanitizeText(f.impact_business || ''),
            sanitizeText(f.remediation_commands || ''),
            sanitizeText(f.prerequisites || ''),
            sanitizeText(f.operational_impact || ''),
            sanitizeText(f.microsoft_docs || ''),
            sanitizeText(f.current_vs_recommended || ''),
            sanitizeText(f.timeline || ''),
            f.affected_count || 0
          ]
        );
      }
      await addLog(assessmentId, 'info', 'Findings saved successfully', category);
    }

    return findings;
  } catch (error) {
    console.error(`Error analyzing ${category}:`, error);
    await addLog(assessmentId, 'error', `Analysis error: ${error.message}`, category);
    return [];
  }
}

function buildPrompt(cat, d) {
  const str = (v, max) => JSON.stringify(v || [], null, 2).substring(0, max);

  const categoryInstructions = {
    Users: `Analiza estos usuarios de Active Directory para identificar vulnerabilidades de seguridad.

**⚠️ VALIDACIÓN CRÍTICA PARA USUARIOS:**
- SOLO genera findings si hay usuarios con el problema en los datos (count > 0)
- Los nombres de usuarios en affected_objects deben ser REALES de los datos analizados
- Los comandos PowerShell deben incluir los SamAccountName reales encontrados
- Si los datos muestran 0 usuarios con un problema, NO generes finding para eso

**BUSCA ESPECÍFICAMENTE (SOLO SI HAY EVIDENCIA):**

1. **Contraseñas que nunca expiran** (PasswordNeverExpires=true AND Enabled=true)
   - Riesgo: Contraseñas comprometidas permanecen válidas indefinidamente
   - CIS Control: 5.2.1 - Ensure password expiration is enabled for all accounts
   - Impacto: Permite persistencia de atacantes, vulnera compliance (NIST 800-53)
   - Comando búsqueda: Get-ADUser -Filter {PasswordNeverExpires -eq $true -and Enabled -eq $true} -Properties PasswordNeverExpires, LastLogonDate
   - Comando fix: Set-ADUser -Identity "SamAccountName" -PasswordNeverExpires $false
   - Verificación: Get-ADUser -Identity "SamAccountName" -Properties PasswordNeverExpires | Select Name, PasswordNeverExpires
   - Timeline: Remediar en 7 días

2. **Usuarios privilegiados excesivos** (miembros de Domain Admins > 5, Enterprise Admins > 3)
   - Riesgo: Exceso de cuentas con privilegios elevados aumenta superficie de ataque exponencialmente
   - CIS Control: 5.1.1 - Minimize administrative accounts to essential personnel only
   - Impacto: Mayor probabilidad de compromiso, dificulta auditoría forense
   - Comando búsqueda: Get-ADGroupMember -Identity "Domain Admins" -Recursive | Select Name, SamAccountName
   - Comando auditoría: Get-ADUser -Filter {AdminCount -eq 1} -Properties AdminCount, LastLogonDate | Select Name, LastLogonDate
   - Recomendación: Implementar JIT (Just-In-Time) Admin Access con Azure AD PIM o PAM
   - Timeline: Revisar en 14 días, justificar cada cuenta

3. **Cuentas inactivas habilitadas** (LastLogonDate > 90 días AND Enabled=true)
   - Riesgo: Cuentas olvidadas son vectores de ataque, difíciles de monitorear
   - CIS Control: 5.3.1 - Disable or remove inactive accounts within 90 days
   - Impacto: Backdoors potenciales, vulnera principio de least privilege
   - Comando búsqueda: $InactiveDate = (Get-Date).AddDays(-90); Get-ADUser -Filter {LastLogonDate -lt $InactiveDate -and Enabled -eq $true} -Properties LastLogonDate
   - Comando fix: Disable-ADAccount -Identity "SamAccountName"
   - Verificación: Get-ADUser -Identity "SamAccountName" -Properties Enabled | Select Name, Enabled
   - Timeline: Deshabilitar en 30 días tras notificar manager

4. **Kerberoasting vulnerable** (ServicePrincipalNames presentes en cuentas de usuario)
   - Riesgo: Atacantes pueden solicitar TGS y crackear passwords offline sin detectar
   - MITRE ATT&CK: T1558.003 (Kerberoasting)
   - Impacto: Compromiso de cuentas de servicio suele llevar a movimiento lateral
   - Comando búsqueda: Get-ADUser -Filter {ServicePrincipalName -like "*"} -Properties ServicePrincipalName, PasswordLastSet
   - Comando auditoría: Get-ADUser -Filter {ServicePrincipalName -like "*"} -Properties PasswordLastSet | Where {$_.PasswordLastSet -lt (Get-Date).AddDays(-365)}
   - Recomendación: Usar gMSA (Group Managed Service Accounts) o passwords > 25 caracteres
   - Timeline: Migrar a gMSA en 60 días

5. **ASREPRoasting vulnerable** (DoNotRequirePreAuth=true)
   - Riesgo: Permite obtener TGT sin autenticación previa, crackearlo offline
   - MITRE ATT&CK: T1558.004 (AS-REP Roasting)
   - Impacto: Bypass de autenticación, extracción de hashes sin credenciales
   - Comando búsqueda: Get-ADUser -Filter {DoNotRequirePreAuth -eq $true} -Properties DoNotRequirePreAuth
   - Comando fix: Set-ADUser -Identity "SamAccountName" -DoNotRequirePreAuth $false
   - Verificación: Get-ADUser -Identity "SamAccountName" -Properties DoNotRequirePreAuth
   - Timeline: Remediar INMEDIATAMENTE (24 horas)

6. **Delegación sin restricciones en usuarios** (TrustedForDelegation=true, no service accounts)
   - Riesgo: Permite ataques de pass-the-ticket, suplantación de cualquier usuario incluyendo DAs
   - MITRE ATT&CK: T1134.005 (SID-History Injection), T1550.003 (Pass the Ticket)
   - Impacto: Escalación de privilegios total, compromiso de dominio
   - Comando búsqueda: Get-ADUser -Filter {TrustedForDelegation -eq $true} -Properties TrustedForDelegation
   - Comando fix: Set-ADUser -Identity "SamAccountName" -TrustedForDelegation $false
   - Alternativa segura: Usar constrained delegation: Set-ADUser -Identity "SamAccountName" -Add @{'msDS-AllowedToDelegateTo'='HTTP/server.domain.com'}
   - Timeline: Remediar INMEDIATAMENTE (24 horas)

7. **Protected Users Group** (cuentas admin NO están en el grupo)
   - Riesgo: Cuentas privilegiadas vulnerables a credential theft, pass-the-hash
   - CIS Control: 5.8.1 - Add privileged accounts to Protected Users security group
   - Comando búsqueda: Get-ADGroupMember "Domain Admins" | Where {(Get-ADUser $_.SamAccountName -Properties MemberOf).MemberOf -notcontains (Get-ADGroup "Protected Users").DistinguishedName}
   - Comando fix: Add-ADGroupMember -Identity "Protected Users" -Members "SamAccountName"
   - Nota: Validar compatibilidad de aplicaciones antes de mover cuentas
   - Timeline: Implementar en 30 días tras testing

**PARA CADA HALLAZGO, PROPORCIONA (EN ESPAÑOL):**
- **Título**: Número REAL de usuarios afectados + problema específico
  Ejemplo: "15 usuarios con contraseñas que nunca expiran detectados"
  
- **Descripción**: 2-3 párrafos con:
  * Número exacto y problema (con datos de los findings)
  * Vector de ataque específico (credential stuffing, brute force, etc.)
  * Impacto en negocio (acceso no autorizado, exfiltración de datos, ransomware)
  * Referencia a CIS/MITRE con número específico
  * Regulaciones afectadas (GDPR Art. 32, NIST 800-53 IA-5)
  
- **Recomendación**: Pasos inmediatamente ejecutables:
  * Comandos PowerShell con SamAccountName reales de los datos
  * Cada comando debe ser copy-paste ready
  * Script completo si son > 5 usuarios: ForEach-Object loop
  * Path de GPO para automatizar: Computer Config > Policies > Security Settings > Account Policies
  * Comando de verificación post-fix
  * Nivel de dificultad: Bajo (1 comando) / Medio (requiere GPO) / Alto (requiere arquitectura)
  
- **Evidencia**: 
  * affected_objects: Array con SamAccountName reales (máximo 10, si son más indicar "...y X más")
  * count: Número total REAL de los datos
  * details: Información específica (ej: "LastLogonDate promedio: 245 días, PasswordLastSet promedio: 18 meses")`,

    GPOs: `Analiza estas Group Policy Objects para identificar configuraciones inseguras.

**⚠️ VALIDACIÓN CRÍTICA PARA GPOs:**
- Si los datos muestran "cpassword": null o "cpassword" no aparece → NO generar finding de cpassword
- Solo reporta GPOs que existan en los datos con valores problemáticos verificables
- Los comandos PowerShell deben ser ESPECÍFICOS para GPO (Get-GPO, Get-GPOReport, Set-GPPermission)
- NO uses comandos no relacionados como Get-WMIObject para problemas de GPO

**BUSCA ESPECÍFICAMENTE (CON EVIDENCIA REAL):**
1. **GPOs sin aplicar** (Links vacíos o deshabilitados)
   - Riesgo: Políticas de seguridad no se están aplicando
   - Comando para verificar: Get-GPO -All | Where-Object {$_.GpoStatus -eq 'AllSettingsDisabled'}
   
2. **Permisos peligrosos** (Authenticated Users puede editar)
   - Riesgo: Usuarios no privilegiados pueden modificar políticas
   - CIS Control: 2.3.10.5 - Restrict GPO modification
   - Comando para auditar: Get-GPPermission -Name "GPO_NAME" -All

3. **GPO Preference Passwords** (cpassword con valor real en XML)
   - ⚠️ SOLO SI encuentras valor cpassword NO NULO
   - Riesgo: Contraseñas almacenadas con cifrado reversible AES-256 crackeado
   - MITRE ATT&CK: T1552.006
   - Comando para buscar: Get-ChildItem "\\\\domain\\SYSVOL\\*\\Policies\\*\\Machine\\Preferences" -Recurse -Filter "*.xml" | Select-String "cpassword"

4. **Configuraciones de seguridad débiles** (SOLO SI ESTÁN EN LOS DATOS):
   - Password policy: MinimumPasswordLength < 14 caracteres
   - Lockout threshold: LockoutThreshold < 5 intentos o 0 (deshabilitado)
   - Maximum password age: > 90 días o 0 (nunca expira)
   - Password history: PasswordHistorySize < 24
   - Comando para verificar: Get-ADDefaultDomainPasswordPolicy

5. **GPOs con configuraciones conflictivas**
   - Múltiples GPOs configurando el mismo setting
   - Comando para detectar: Get-GPOReport -Name "GPO_NAME" -ReportType HTML

**PARA CADA HALLAZGO, PROPORCIONA:**
- **Título**: En ESPAÑOL, específico con número de GPOs afectadas
  Ejemplo: "2 GPOs con configuraciones de contraseña débiles detectadas"
  
- **Descripción**: En ESPAÑOL, impacto en la postura de seguridad:
  * Qué configuración específica está mal (con valores reales de los datos)
  * Por qué facilita ataques (brute force, credential stuffing, etc.)
  * Impacto en cumplimiento (CIS, NIST, ISO 27001)
  
- **Recomendación**: En ESPAÑOL, pasos ACCIONABLES:
  * Path en GPMC: Computer Configuration > Policies > Windows Settings > Security Settings > ...
  * Configuración correcta según CIS Benchmark (valor específico)
  * Comandos PowerShell SOLO para GPO (Get-GPO, Set-GPLink, etc.)
  * Cada comando debe incluir el nombre real del GPO de los datos
  * Comando de verificación: Get-GPOReport -Name "NOMBRE_REAL" -ReportType XML
  
- **Evidencia**: Nombres REALES de GPOs de los datos y sus configuraciones problemáticas con valores específicos`,

    Computers: `Analiza estos equipos de Active Directory para identificar riesgos.

**BUSCA ESPECÍFICAMENTE:**
1. **Sistemas operativos obsoletos** (Windows Server 2008/2012, Windows 7/8)
   - Riesgo: Sin soporte, vulnerabilidades sin parchar
   - CIS Control: 7.1 - Maintain supported OS versions

2. **Equipos inactivos** (LastLogonDate > 90 días)
   - Riesgo: Equipos comprometidos no detectados
   
3. **Delegación sin restricciones** (TrustedForDelegation=true, no DC)
   - Riesgo: Permite ataques de pass-the-ticket
   - MITRE ATT&CK: T1550.003

4. **Controladores de dominio**:
   - Versiones de OS desactualizadas
   - Roles FSMO mal distribuidos
   - Sin redundancia geográfica

**PARA CADA HALLAZGO, PROPORCIONA:**
- **Título**: Número de equipos afectados y tipo de problema
- **Descripción**: Riesgo específico y vectores de ataque
- **Recomendación**: Plan de remediación:
  * Para OS obsoletos: Plan de migración/actualización
  * Para delegación: Cómo deshabilitar o restringir
  * Comandos PowerShell para implementar
- **Evidencia**: Lista de equipos (hostname, OS, última actividad)`,

    Groups: `Analiza estos grupos de Active Directory para identificar problemas de privilegios.

**BUSCA ESPECÍFICAMENTE:**
1. **Grupos privilegiados con muchos miembros** (Domain Admins > 5, Enterprise Admins > 3)
   - Riesgo: Exceso de privilegios, difícil auditar
   - CIS Control: 5.1 - Minimize administrative accounts

2. **Usuarios no autorizados en grupos admin**
   - Riesgo: Escalación de privilegios no documentada
   
3. **Grupos vacíos o sin uso**
   - Riesgo: Confusión en gestión de permisos
   
4. **Anidamiento excesivo** (grupos dentro de grupos > 3 niveles)
   - Riesgo: Permisos heredados no evidentes

5. **Protected Users group** (debe contener cuentas privilegiadas)
   - CIS Control: 5.8 - Use Protected Users group

**PARA CADA HALLAZGO, PROPORCIONA:**
- **Título**: Grupo afectado y número de miembros
- **Descripción**: Por qué es un riesgo de seguridad
- **Recomendación**: Pasos de remediación:
  * Revisar y justificar cada miembro
  * Implementar RBAC (Role-Based Access Control)
  * Usar grupos temporales con PAM
  * Comandos PowerShell para auditar
- **Evidencia**: Nombres de grupos y miembros problemáticos`,

    DCHealth: `Analiza la salud y seguridad de los controladores de dominio.

**BUSCA ESPECÍFICAMENTE:**
1. **Problemas de replicación** (ConsecutiveReplicationFailures > 0)
   - Riesgo: Inconsistencia de datos, posible DoS
   
2. **Versiones de OS obsoletas** (< Windows Server 2016)
   - Riesgo: Vulnerabilidades sin parchar, sin soporte
   
3. **Roles FSMO** (todos en un solo DC)
   - Riesgo: Single point of failure
   
4. **KRBTGT password age** (> 180 días)
   - Riesgo: Golden ticket attacks
   - MITRE ATT&CK: T1558.001

5. **SMBv1 habilitado**
   - Riesgo: Vulnerable a EternalBlue, ransomware
   - CIS Control: 2.3.11.9 - Disable SMBv1

6. **NTLM authentication** (no restringido)
   - Riesgo: Pass-the-hash attacks
   - CIS Control: 2.3.11.7 - Restrict NTLM

7. **AD Recycle Bin** (deshabilitado)
   - Riesgo: No se pueden recuperar objetos eliminados
   
8. **Tombstone Lifetime** (< 180 días)
   - Riesgo: Pérdida de datos en backups antiguos

**PARA CADA HALLAZGO, PROPORCIONA:**
- **Título**: Problema específico del DC
- **Descripción**: Impacto en disponibilidad y seguridad
- **Recomendación**: Pasos detallados de remediación:
  * Para KRBTGT: Procedimiento de rotación segura
  * Para SMBv1: Cómo deshabilitar sin romper servicios
  * Para replicación: Diagnóstico y solución
  * Comandos PowerShell exactos
  * Referencias a Microsoft best practices
- **Evidencia**: Estado actual de cada DC`
  };

  const instruction = categoryInstructions[cat] || `Analiza los siguientes datos de ${cat} para vulnerabilidades de seguridad.`;

  return `${instruction}

**DATOS A ANALIZAR** (primeros 4000 caracteres):
${str(d, 4000)}

**INSTRUCCIONES CRÍTICAS PARA TU RESPUESTA:**

**🚨 REGLA FUNDAMENTAL - CERO FALSOS POSITIVOS:**
- **NO** generes un finding SI NO HAY EVIDENCIA CONCRETA del problema
- **NO** reportes algo como crítico si los datos dicen "no se observa" o "0 elementos"
- **NO** inventes problemas basándote en ausencia de datos
- Solo genera findings cuando los datos DEMUESTREN un problema real y verificable

**VALIDACIÓN DE EVIDENCIA OBLIGATORIA:**
Antes de generar cada finding, verifica:
✅ ¿Hay objetos afectados reales en los datos? (count > 0)
✅ ¿Los nombres/valores de affected_objects son específicos y verificables?
✅ ¿La evidencia muestra claramente el problema?
✅ ¿Los comandos PowerShell son relevantes al problema específico identificado?

**EJEMPLO DE LÓGICA CORRECTA:**
❌ MAL: "No se observan cpasswords" → Generar finding CRITICAL
✅ BIEN: "No se observan cpasswords" → NO generar finding (no hay problema)

❌ MAL: Incluir comando \`Get-WMIObject\` en finding de GPO
✅ BIEN: Solo comandos relacionados directamente con GPO (\`Get-GPO\`, \`Get-GPOReport\`)

**ESTRUCTURA PARA CADA FINDING:**
1. **severity**: "critical" o "high" (SOLO si impacto es real y demostrable)
   
2. **title**: En ESPAÑOL, formato "X [objetos] [problema específico]"
   Ejemplo: "15 usuarios con contraseñas que nunca expiran"
   NO usar: "Password issues detected"

3. **description**: En ESPAÑOL, 2-3 párrafos con:
   - Qué problema específico se encontró (con números reales)
   - Por qué es peligroso según CIS/MITRE
   - Impacto de negocio concreto (pérdida de datos, compromiso, downtime)
   - Qué vectores de ataque habilita
   - Timeline sugerido de remediación (Inmediato/30 días/90 días)

4. **recommendation**: En ESPAÑOL, pasos ACCIONABLES:
   - Comandos PowerShell ESPECÍFICOS con parámetros reales de los datos
   - Cada comando debe ser copy-paste ejecutable
   - Configuración de GPO paso a paso (GPMC path completo)
   - Referencia a CIS Benchmark específico (ej: "CIS Control 5.2.1")
   - Link a documentación Microsoft si aplica
   - Comando de verificación para confirmar que se aplicó
   - Nivel de dificultad: Bajo/Medio/Alto

5. **evidence**: Objeto JSON con:
   - **affected_objects**: Array con nombres REALES de los datos (máx 10)
   - **count**: Número TOTAL verificable en los datos
   - **details**: String con contexto adicional específico

**CALIDAD DE COMANDOS POWERSHELL:**
✅ Usar cmdlets oficiales: Get-ADUser, Set-ADUser, Get-GPO, etc.
✅ Incluir filtros específicos: -Filter, -Properties
✅ Incluir parámetros de los objetos reales encontrados
❌ NO usar comandos genéricos irrelevantes al problema

**CONDICIÓN DE SALIDA:**
- Si después de analizar NO encuentras problemas críticos o altos con evidencia real
- Devuelve: {"findings": []}
- NO fuerces findings para "rellenar"

**IDIOMA:**
🇪🇸 ESPAÑOL OBLIGATORIO en: title, description, recommendation, evidence.details
- Usa terminología técnica correcta en español
- Mantén nombres de comandos/parámetros en inglés (ej: Set-ADUser -PasswordNeverExpires $false)

**IMPACTO DE NEGOCIO (agregar en description):**
- Riesgo financiero potencial
- Cumplimiento regulatorio afectado (GDPR, SOX, HIPAA si aplica)
- SLA de disponibilidad en riesgo
`;
}

async function callAI(prompt, provider, model, apiKey) {
  try {
    console.log(`[${timestamp()}] [${provider.toUpperCase()}] Making API call with model ${model}...`);
    
    if (provider === 'openai') {
      return await callOpenAI(prompt, model, apiKey);
    } else if (provider === 'gemini') {
      return await callGemini(prompt, model, apiKey);
    } else if (provider === 'deepseek') {
      return await callDeepSeek(prompt, model, apiKey);
    } else {
      throw new Error(`Unknown AI provider: ${provider}`);
    }
  } catch (error) {
    console.error(`[${timestamp()}] [${provider.toUpperCase()}] Call failed:`, error.message);
    return [];
  }
}

async function callOpenAI(prompt, model, key) {
  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${key}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: model,
        messages: [
          {
            role: 'system',
            content: `Eres un analista senior de seguridad de Active Directory con certificaciones CISSP, OSCP y experiencia en auditorías de cumplimiento.

PRINCIPIOS FUNDAMENTALES:
1. CERO TOLERANCIA A FALSOS POSITIVOS - Solo reporta problemas que existan y sean verificables en los datos
2. EVIDENCIA PRIMERO - Si no hay evidencia concreta (count > 0, nombres específicos), NO generes finding
3. COMANDOS RELEVANTES - Cada comando PowerShell debe estar directamente relacionado con el problema específico
4. CALIDAD SOBRE CANTIDAD - Mejor 3 findings de alta calidad que 10 mediocres
5. TODO EN ESPAÑOL - Excepto nombres de comandos técnicos

PROCESO DE VALIDACIÓN ANTES DE REPORTAR:
✓ ¿Los datos muestran el problema claramente?
✓ ¿El count es > 0 con objetos reales identificados?
✓ ¿Los comandos PowerShell son específicos y ejecutables?
✓ ¿La severidad está justificada por el impacto real?
✓ ¿El finding ayuda al administrador a mejorar la seguridad?

Si cualquier respuesta es NO, descarta el finding.

FORMATO DE SALIDA JSON OBLIGATORIO:
Cada finding DEBE incluir estos campos para personal de TI:

{
  "findings": [
    {
      "title": "Título específico con número de afectados",
      "severity": "critical|high|medium|low",
      "description": "Descripción técnica detallada",
      "recommendation": "Pasos de remediación ejecutables",
      "mitre_attack": "T1558.003 - Kerberoasting | T1078 - Valid Accounts | etc",
      "cis_control": "5.2.1 - Ensure password expiration | CIS Control específico",
      "impact_business": "Impacto financiero, regulatorio, reputacional específico",
      "remediation_commands": "Comandos PowerShell copy-paste ready con nombres reales de objetos",
      "prerequisites": "Requisitos antes de remediar (backups, testing, coordinación)",
      "operational_impact": "Impacto en producción (reinicio servicios, usuarios afectados, downtime)",
      "microsoft_docs": "https://learn.microsoft.com/... URLs oficiales de Microsoft Docs",
      "current_vs_recommended": "Valor Actual: X | Recomendado: Y según CIS/NIST",
      "timeline": "24h - Inmediato | 7d | 30d | 60d | 90d",
      "affected_count": 15,
      "evidence": {
        "affected_objects": ["user1", "user2"],
        "count": 15,
        "details": "Detalles técnicos específicos"
      }
    }
  ]
}

EJEMPLOS DE CAMPOS TÉCNICOS:

mitre_attack: "T1558.003 - Kerberoasting: Permite extracción de TGS y crackeo offline de contraseñas"

remediation_commands: 
"# Listar usuarios afectados
Get-ADUser -Filter {ServicePrincipalName -like '*'} -Properties ServicePrincipalName, PasswordLastSet | Format-Table Name, PasswordLastSet

# Remediar (opción 1): Migrar a gMSA
New-ADServiceAccount -Name svc_app_gMSA -DNSHostName app.domain.com -PrincipalsAllowedToRetrieveManagedPassword 'APP_SERVERS$'

# Remediar (opción 2): Passwords complejas > 25 caracteres
Set-ADAccountPassword -Identity 'svc_app' -Reset -NewPassword (ConvertTo-SecureString -AsPlainText 'ComplexP@ssw0rd!25Chars+' -Force)

# Verificación
Get-ADServiceAccount -Identity svc_app_gMSA -Properties * | Select Name, Enabled, PrincipalsAllowedToRetrieveManagedPassword"

prerequisites: "✓ Backup de AD antes de cambios | ✓ Validar compatibilidad de aplicaciones con gMSA (Windows Server 2012+) | ✓ Coordinar con equipos de aplicaciones | ✓ Ventana de mantenimiento programada"

operational_impact: "⚠️ MEDIO: Requiere reiniciar servicios que usan la cuenta. Coordinar con equipos de aplicaciones. Downtime estimado: 5-15 minutos por servicio. No afecta usuarios finales si se ejecuta fuera de horario laboral."

microsoft_docs: "https://learn.microsoft.com/en-us/windows-server/security/group-managed-service-accounts/group-managed-service-accounts-overview | https://learn.microsoft.com/en-us/powershell/module/activedirectory/new-adserviceaccount"

current_vs_recommended: "Actual: 8 cuentas de servicio con SPN usando contraseñas estándar (<15 caracteres), PasswordLastSet promedio: 18 meses | Recomendado: Migrar a gMSA o contraseñas >25 caracteres aleatorios, rotación automática cada 30 días (CIS Benchmark 5.2.3)"

timeline: "60d - Migración gradual por aplicación, testing en QA primero"`
          },
          { role: 'user', content: prompt.substring(0, MAX_PROMPT) }
        ],
        response_format: {
          type: 'json_schema',
          json_schema: {
            name: 'security_findings',
            strict: false,
            schema: {
              type: 'object',
              properties: {
                findings: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      severity: {
                        type: 'string',
                        enum: ['critical', 'high', 'medium', 'low']
                      },
                      title: { type: 'string' },
                      description: { type: 'string' },
                      recommendation: { type: 'string' },
                      mitre_attack: { type: 'string' },
                      cis_control: { type: 'string' },
                      impact_business: { type: 'string' },
                      remediation_commands: { type: 'string' },
                      prerequisites: { type: 'string' },
                      operational_impact: { type: 'string' },
                      microsoft_docs: { type: 'string' },
                      current_vs_recommended: { type: 'string' },
                      timeline: { type: 'string' },
                      affected_count: { type: 'number' },
                      evidence: {
                        type: 'object',
                        additionalProperties: false,
                        properties: {
                          affected_objects: { type: 'array', items: { type: 'string' } },
                          count: { type: 'number' },
                          details: { type: 'string' }
                        },
                        required: ['affected_objects', 'count', 'details']
                      }
                    },
                    required: ['severity', 'title', 'description', 'recommendation', 'evidence'],
                    additionalProperties: false
                  }
                }
              },
              required: ['findings'],
              additionalProperties: false
            }
          }
        }
      })
    });

    if (!res.ok) {
      const errorText = await res.text();
      console.error(`[${timestamp()}] [OpenAI] API error: ${res.status} - ${errorText}`);
      throw new Error(`OpenAI API error: ${res.status} - ${errorText}`);
    }

    const result = await res.json();
    console.log(`[${timestamp()}] [OpenAI] Response received:`, JSON.stringify(result).substring(0, 500));

    const content = result.choices?.[0]?.message?.content;

    if (content) {
      const parsed = JSON.parse(content);
      console.log(`[${timestamp()}] [OpenAI] Parsed ${parsed.findings?.length || 0} findings`);
      return parsed.findings || [];
    }

    console.log(`[${timestamp()}] [OpenAI] No content in response`);
    return [];
  } catch (e) {
    console.error(`[${timestamp()}] [OpenAI] Call failed:`, e.message);
    console.error(`[${timestamp()}] [OpenAI] Stack:`, e.stack);
    throw e;
  }
}

async function callGemini(prompt, model, key) {
  const systemPrompt = `Eres un analista senior de seguridad de Active Directory con certificaciones CISSP, OSCP y experiencia en auditorías de cumplimiento.

PRINCIPIOS FUNDAMENTALES:
1. CERO TOLERANCIA A FALSOS POSITIVOS - Solo reporta problemas que existan y sean verificables en los datos
2. EVIDENCIA PRIMERO - Si no hay evidencia concreta (count > 0, nombres específicos), NO generes finding
3. COMANDOS RELEVANTES - Cada comando PowerShell debe estar directamente relacionado con el problema específico
4. CALIDAD SOBRE CANTIDAD - Mejor 3 findings de alta calidad que 10 mediocres
5. TODO EN ESPAÑOL - Excepto nombres de comandos técnicos

FORMATO JSON REQUERIDO: Devuelve un objeto JSON con array "findings" que contenga objetos con: severity, title, description, recommendation, evidence (con affected_objects, count, details), y opcionalmente: mitre_attack, cis_control, impact_business, remediation_commands, prerequisites, operational_impact, microsoft_docs, current_vs_recommended, timeline, affected_count`;

  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{
        parts: [{ text: systemPrompt + '\n\n' + prompt.substring(0, MAX_PROMPT) }]
      }],
      generationConfig: {
        temperature: 0.2,
        topP: 0.95,
        topK: 40,
        maxOutputTokens: 8192,
        responseMimeType: 'application/json'
      }
    })
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error(`[${timestamp()}] [Gemini] API error: ${res.status} - ${errorText}`);
    throw new Error(`Gemini API error: ${res.status} - ${errorText}`);
  }

  const result = await res.json();
  console.log(`[${timestamp()}] [Gemini] Response received:`, JSON.stringify(result).substring(0, 500));

  const content = result.candidates?.[0]?.content?.parts?.[0]?.text;
  if (content) {
    const parsed = JSON.parse(content);
    console.log(`[${timestamp()}] [Gemini] Parsed ${parsed.findings?.length || 0} findings`);
    return parsed.findings || [];
  }

  console.log(`[${timestamp()}] [Gemini] No content in response`);
  return [];
}

async function callDeepSeek(prompt, model, key) {
  // DeepSeek usa la misma API que OpenAI
  const res = await fetch('https://api.deepseek.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${key}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: model,
      messages: [
        {
          role: 'system',
          content: `Eres un analista senior de seguridad de Active Directory con certificaciones CISSP, OSCP y experiencia en auditorías de cumplimiento.

PRINCIPIOS FUNDAMENTALES:
1. CERO TOLERANCIA A FALSOS POSITIVOS - Solo reporta problemas que existan y sean verificables en los datos
2. EVIDENCIA PRIMERO - Si no hay evidencia concreta (count > 0, nombres específicos), NO generes finding
3. COMANDOS RELEVANTES - Cada comando PowerShell debe estar directamente relacionado con el problema específico
4. CALIDAD SOBRE CANTIDAD - Mejor 3 findings de alta calidad que 10 mediocres
5. TODO EN ESPAÑOL - Excepto nombres de comandos técnicos

FORMATO JSON REQUERIDO: Devuelve SOLO un objeto JSON válido con este formato:
{
  "findings": [
    {
      "title": "string",
      "severity": "critical|high|medium|low",
      "description": "string",
      "recommendation": "string",
      "evidence": {
        "affected_objects": ["string"],
        "count": number,
        "details": "string"
      },
      "mitre_attack": "string (opcional)",
      "cis_control": "string (opcional)",
      "timeline": "string (opcional)",
      "affected_count": number (opcional)
    }
  ]
}`
        },
        { role: 'user', content: prompt.substring(0, MAX_PROMPT) }
      ],
      temperature: 0.2,
      response_format: { type: 'json_object' }
    })
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error(`[${timestamp()}] [DeepSeek] API error: ${res.status} - ${errorText}`);
    throw new Error(`DeepSeek API error: ${res.status} - ${errorText}`);
  }

  const result = await res.json();
  console.log(`[${timestamp()}] [DeepSeek] Response received:`, JSON.stringify(result).substring(0, 500));

  const content = result.choices?.[0]?.message?.content;
  if (content) {
    const parsed = JSON.parse(content);
    console.log(`[${timestamp()}] [DeepSeek] Parsed ${parsed.findings?.length || 0} findings`);
    return parsed.findings || [];
  }

  console.log(`[${timestamp()}] [DeepSeek] No content in response`);
  return [];
}

// Main Processing Function
async function processAssessment(assessmentId, jsonData) {
  try {
    await addLog(assessmentId, 'info', '🚀 Starting processing on Self-Hosted VPS');

    // 1. Store Raw Data (compressed)
    const jsonString = JSON.stringify(jsonData);
    const compressed = zlib.gzipSync(jsonString);
    const compressionRatio = Math.round((1 - compressed.length/jsonString.length) * 100);
    console.log(`[${timestamp()}] Compressed ${Math.round(jsonString.length/1024/1024)} MB to ${Math.round(compressed.length/1024/1024)} MB (${compressionRatio}% reduction)`);
    
    await pool.query(
      'INSERT INTO assessment_data (assessment_id, data) VALUES ($1, $2)',
      [assessmentId, compressed]
    );
    await addLog(assessmentId, 'info', `✅ Raw data stored (compressed ${compressionRatio}%)`);

    // 2. Identify Categories
    const availableCategories = [];
    for (const category of CATEGORIES) {
      const data = extractCategoryData(jsonData, category);
      if (data && data.length > 0) {
        availableCategories.push({ id: category, count: data.length, data });
      }
    }

    if (availableCategories.length === 0) {
      throw new Error('No valid categories found');
    }

    // 3. Update Status to Analyzing
    const progressData = availableCategories.reduce((acc, cat) => {
      acc[cat.id] = { status: 'pending', progress: 0, count: cat.count };
      return acc;
    }, {});

    await pool.query(
      'UPDATE assessments SET status = $1, analysis_progress = $2 WHERE id = $3',
      ['analyzing', progressData, assessmentId]
    );

    // 4. Process Categories
    for (const categoryInfo of availableCategories) {
      const { id: category, data } = categoryInfo;

      progressData[category].status = 'processing';
      await pool.query('UPDATE assessments SET analysis_progress = $1 WHERE id = $2', [progressData, assessmentId]);

      await analyzeCategory(assessmentId, category, data);

      progressData[category].status = 'completed';
      progressData[category].progress = 100;
      await pool.query('UPDATE assessments SET analysis_progress = $1 WHERE id = $2', [progressData, assessmentId]);
    }

    // 5. Finish
    await pool.query(
      'UPDATE assessments SET status = $1, completed_at = NOW() WHERE id = $2',
      ['completed', assessmentId]
    );
    await addLog(assessmentId, 'info', '🎉 Analysis completed successfully');

  } catch (error) {
    console.error('Fatal processing error:', error);
    await addLog(assessmentId, 'error', `Fatal error: ${error.message}`);
    await pool.query('UPDATE assessments SET status = $1 WHERE id = $2', ['failed', assessmentId]);
  }
}

// API Endpoint
app.post('/api/process-assessment', async (req, res) => {
  try {
    const { assessmentId, jsonData, domainName } = req.body;

    if (!jsonData) return res.status(400).json({ error: 'Missing jsonData' });

    // Create assessment if ID not provided (or if it doesn't exist)
    let finalAssessmentId = assessmentId;
    if (!finalAssessmentId) {
      const result = await pool.query(
        'INSERT INTO assessments (domain, status) VALUES ($1, $2) RETURNING id',
        [domainName || 'Unknown Domain', 'analyzing']
      );
      finalAssessmentId = result.rows[0].id;
    } else {
      // Check if exists, if not create
      const check = await pool.query('SELECT id FROM assessments WHERE id = $1', [assessmentId]);
      if (check.rows.length === 0) {
        await pool.query(
          'INSERT INTO assessments (id, domain, status) VALUES ($1, $2, $3)',
          [assessmentId, domainName || 'Unknown Domain', 'analyzing']
        );
      }
    }

    // Start processing in background
    processAssessment(finalAssessmentId, jsonData).catch(err => console.error('Background error:', err));

    res.json({ success: true, assessmentId: finalAssessmentId, message: 'Processing started' });

  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', db: 'connected' });
  } catch (e) {
    res.status(500).json({ status: 'error', db: e.message });
  }
});

// GET /api/config/ai - Get AI configuration
app.get('/api/config/ai', async (req, res) => {
  try {
    const provider = (await getConfig('ai_provider')) || 'openai';
    const model = (await getConfig('ai_model')) || 'gpt-4o-mini';
    const hasOpenAIKey = !!(await getConfig('openai_api_key') || process.env.OPENAI_API_KEY);
    const hasGeminiKey = !!await getConfig('gemini_api_key');
    const hasDeepSeekKey = !!await getConfig('deepseek_api_key');
    
    res.json({
      provider,
      model,
      available_providers: {
        openai: hasOpenAIKey,
        gemini: hasGeminiKey,
        deepseek: hasDeepSeekKey
      },
      models: {
        openai: ['gpt-4o-mini', 'gpt-4o', 'gpt-4-turbo'],
        gemini: ['gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-1.0-pro'],
        deepseek: ['deepseek-chat', 'deepseek-coder']
      }
    });
  } catch (error) {
    console.error('Error fetching AI config:', error);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/config/ai - Update AI configuration
app.post('/api/config/ai', async (req, res) => {
  try {
    const { provider, model, api_keys } = req.body;
    
    if (provider) {
      await setConfig('ai_provider', provider);
    }
    
    if (model) {
      await setConfig('ai_model', model);
    }
    
    if (api_keys) {
      if (api_keys.openai) await setConfig('openai_api_key', api_keys.openai);
      if (api_keys.gemini) await setConfig('gemini_api_key', api_keys.gemini);
      if (api_keys.deepseek) await setConfig('deepseek_api_key', api_keys.deepseek);
    }
    
    res.json({ success: true, message: 'AI configuration updated' });
  } catch (error) {
    console.error('Error updating AI config:', error);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/assessments - Create a new assessment
app.post('/api/assessments', async (req, res) => {
  const { domain } = req.body;
  if (!domain) {
    return res.status(400).json({ error: 'Domain is required' });
  }

  try {
    const result = await pool.query(
      'INSERT INTO assessments (domain, status) VALUES ($1, $2) RETURNING *',
      [domain, 'pending']
    );
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error creating assessment:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/assessments - List all assessments
app.get('/api/assessments', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM assessments ORDER BY created_at DESC'
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching assessments:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/assessments/:id - Get single assessment
app.get('/api/assessments/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      'SELECT * FROM assessments WHERE id = $1',
      [id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Assessment not found' });
    }
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching assessment:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/assessments/:id/findings - Get findings for an assessment
app.get('/api/assessments/:id/findings', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      'SELECT * FROM findings WHERE assessment_id = $1 ORDER BY CASE severity WHEN \'critical\' THEN 1 WHEN \'high\' THEN 2 WHEN \'medium\' THEN 3 WHEN \'low\' THEN 4 ELSE 5 END',
      [id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching findings:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/assessments/:id/logs - Get logs for an assessment
app.get('/api/assessments/:id/logs', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      'SELECT * FROM assessment_logs WHERE assessment_id = $1 ORDER BY created_at ASC',
      [id]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching logs:', error);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/assessments/:id/data - Get raw data for an assessment
app.get('/api/assessments/:id/data', async (req, res) => {
  const { id } = req.params;
  console.log(`[${timestamp()}] [API] Fetching raw data for assessment ${id}`);
  try {
    const result = await pool.query(
      'SELECT data FROM assessment_data WHERE assessment_id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      console.log(`[${timestamp()}] [API] No raw data found for assessment ${id}`);
      return res.status(404).json({ error: 'Assessment data not found' });
    }

    // Decompress data in streaming mode to reduce memory usage
    const compressedData = result.rows[0].data;
    
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Encoding', 'gzip');
    
    // Send compressed data directly, let browser decompress
    console.log(`[${timestamp()}] [API] Sending compressed raw data for assessment ${id} (${Math.round(compressedData.length/1024/1024)} MB)`);
    res.send(compressedData);
  } catch (error) {
    console.error(`[${timestamp()}] [API] Error fetching assessment data:`, error);
    res.status(500).json({ error: error.message });
  }
});

// DELETE /api/assessments/:id - Delete an assessment
app.delete('/api/assessments/:id', async (req, res) => {
  const { id } = req.params;
  try {
    // Cascading delete should handle related data if configured, 
    // but let's be safe and delete related data first if needed.
    // Our schema uses ON DELETE CASCADE so deleting assessment is enough.

    const result = await pool.query(
      'DELETE FROM assessments WHERE id = $1 RETURNING *',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Assessment not found' });
    }

    res.json({ message: 'Assessment deleted successfully' });
  } catch (error) {
    console.error('Error deleting assessment:', error);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/assessments/:id/reset - Reset an assessment
app.post('/api/assessments/:id/reset', async (req, res) => {
  const { id } = req.params;
  try {
    // Delete findings
    await pool.query('DELETE FROM findings WHERE assessment_id = $1', [id]);

    // Reset assessment status
    const result = await pool.query(
      `UPDATE assessments 
       SET status = 'pending', 
           analysis_progress = '{"total": 0, "current": null, "completed": 0, "categories": []}',
           completed_at = NULL,
           updated_at = NOW()
       WHERE id = $1 RETURNING *`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Assessment not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error resetting assessment:', error);
    res.status(500).json({ error: error.message });
  }
});

// POST /api/upload-large-file - Handle large file uploads (.json or .zip)
const upload = multer({ 
  dest: '/tmp/uploads/',
  limits: { 
    fileSize: 5 * 1024 * 1024 * 1024 // 5GB max file size
  }
});

app.post('/api/upload-large-file', upload.single('file'), async (req, res) => {
  const { assessmentId } = req.body;
  const filePath = req.file?.path;

  if (!assessmentId || !filePath) {
    return res.status(400).json({ error: 'Missing assessmentId or file' });
  }

  try {
    console.log(`[${timestamp()}] [UPLOAD] Processing file: ${req.file.originalname} (${(req.file.size / 1024 / 1024).toFixed(2)} MB)`);
    await addLog(assessmentId, 'info', `Archivo recibido: ${req.file.originalname} (${(req.file.size / 1024 / 1024).toFixed(2)} MB)`);

    let jsonData;
    const isZip = req.file.originalname.endsWith('.zip');

    if (isZip) {
      // Decompress ZIP file
      await addLog(assessmentId, 'info', 'Descomprimiendo archivo ZIP...');
      console.log(`[${timestamp()}] [UPLOAD] Decompressing ZIP file...`);
      
      const zip = new AdmZip(filePath);
      const entries = zip.getEntries();
      
      // Find the JSON file inside ZIP
      const jsonEntry = entries.find(e => e.entryName.endsWith('.json') && !e.isDirectory);
      
      if (!jsonEntry) {
        await addLog(assessmentId, 'error', 'No se encontró archivo JSON dentro del ZIP');
        return res.status(400).json({ error: 'No JSON file found in ZIP' });
      }

      console.log(`[${timestamp()}] [UPLOAD] Found JSON entry: ${jsonEntry.entryName}`);
      let jsonContent = zip.readAsText(jsonEntry);
      
      // Remove BOM (Byte Order Mark) if present
      if (jsonContent.charCodeAt(0) === 0xFEFF) {
        console.log(`[${timestamp()}] [UPLOAD] Removing BOM from JSON content`);
        jsonContent = jsonContent.substring(1);
      }
      
      jsonData = JSON.parse(jsonContent);
      
      await addLog(assessmentId, 'info', `Archivo descomprimido: ${jsonEntry.entryName}`);
    } else {
      // Read JSON directly
      console.log(`[${timestamp()}] [UPLOAD] Reading JSON file...`);
      let jsonContent = fs.readFileSync(filePath, 'utf8');
      
      // Remove BOM (Byte Order Mark) if present
      if (jsonContent.charCodeAt(0) === 0xFEFF) {
        console.log(`[${timestamp()}] [UPLOAD] Removing BOM from JSON content`);
        jsonContent = jsonContent.substring(1);
      }
      
      jsonData = JSON.parse(jsonContent);
    }

    console.log(`[${timestamp()}] [UPLOAD] JSON parsed successfully`);
    await addLog(assessmentId, 'info', 'Datos JSON procesados correctamente');

    // Compress JSON before storing
    const jsonString = JSON.stringify(jsonData);
    const compressed = zlib.gzipSync(jsonString);
    const compressionRatio = Math.round((1 - compressed.length/jsonString.length) * 100);
    console.log(`[${timestamp()}] [UPLOAD] Compressed ${Math.round(jsonString.length/1024/1024)} MB to ${Math.round(compressed.length/1024/1024)} MB (${compressionRatio}% reduction)`);
    console.log(`[${timestamp()}] [UPLOAD] Compressed data type: ${typeof compressed}, isBuffer: ${Buffer.isBuffer(compressed)}`);
    await addLog(assessmentId, 'info', `Comprimiendo datos (${compressionRatio}% reducción)...`);

    // Store compressed data in assessment_data table (Buffer is automatically converted to bytea by pg driver)
    await addLog(assessmentId, 'info', 'Guardando datos comprimidos en la base de datos...');
    await pool.query(
      'INSERT INTO assessment_data (assessment_id, data) VALUES ($1, $2) ON CONFLICT (assessment_id) DO UPDATE SET data = $2',
      [assessmentId, compressed]
    );

    // Update assessment status
    await pool.query(
      'UPDATE assessments SET status = $1, updated_at = NOW() WHERE id = $2',
      ['uploaded', assessmentId]
    );

    console.log(`[${timestamp()}] [UPLOAD] Data stored in database`);
    await addLog(assessmentId, 'info', 'Datos guardados. Iniciando análisis...');

    // Start analysis process (async, don't wait)
    processAssessmentData(assessmentId, jsonData).catch(err => {
      console.error(`[${timestamp()}] [UPLOAD] Background analysis error:`, err);
      addLog(assessmentId, 'error', `Error en análisis: ${err.message}`);
    });

    // Return success immediately
    res.json({
      success: true,
      message: 'Archivo procesado correctamente',
      status: 'analyzing',
      fileType: isZip ? 'zip' : 'json',
      originalSize: req.file.size
    });

  } catch (error) {
    console.error(`[${timestamp()}] [UPLOAD] Error processing file:`, error);
    await addLog(assessmentId, 'error', `Error procesando archivo: ${error.message}`);
    
    res.status(500).json({ 
      error: 'Error processing file', 
      details: error.message 
    });
  } finally {
    // Clean up temporary file
    if (filePath && fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
        console.log(`[${timestamp()}] [UPLOAD] Temporary file deleted: ${filePath}`);
      } catch (cleanupError) {
        console.error(`[${timestamp()}] [UPLOAD] Error deleting temp file:`, cleanupError);
      }
    }
  }
});

// Helper function to process assessment data
async function processAssessmentData(assessmentId, jsonData) {
  try {
    console.log(`[${timestamp()}] [PROCESS] Starting analysis for assessment ${assessmentId}`);
    await addLog(assessmentId, 'info', 'Iniciando análisis de categorías...');

    // Update assessment status
    await pool.query(
      'UPDATE assessments SET status = $1, analysis_progress = $2, updated_at = NOW() WHERE id = $3',
      ['analyzing', JSON.stringify({ total: CATEGORIES.length, completed: 0, current: null }), assessmentId]
    );

    let completedCategories = 0;

    // Process each category
    for (const category of CATEGORIES) {
      try {
        await addLog(assessmentId, 'info', `Analizando categoría: ${category}`, category);
        
        const categoryData = extractCategoryData(jsonData, category);
        
        if (!categoryData || categoryData.length === 0) {
          await addLog(assessmentId, 'info', `Categoría ${category} sin datos, omitiendo`, category);
          completedCategories++;
          continue;
        }

        await addLog(assessmentId, 'info', `Procesando ${categoryData.length} elementos de ${category}`, category);
        
        // Analyze with AI
        const findings = await analyzeCategory(assessmentId, category, categoryData);
        
        if (findings && findings.length > 0) {
          await addLog(assessmentId, 'info', `${findings.length} hallazgos encontrados en ${category}`, category);
        } else {
          await addLog(assessmentId, 'info', `No se encontraron hallazgos en ${category}`, category);
        }

        completedCategories++;

        // Update progress
        await pool.query(
          'UPDATE assessments SET analysis_progress = $1, updated_at = NOW() WHERE id = $2',
          [JSON.stringify({ total: CATEGORIES.length, completed: completedCategories, current: category }), assessmentId]
        );

      } catch (categoryError) {
        console.error(`[${timestamp()}] [PROCESS] Error analyzing ${category}:`, categoryError);
        await addLog(assessmentId, 'error', `Error en categoría ${category}: ${categoryError.message}`, category);
      }
    }

    // Mark as completed
    await pool.query(
      'UPDATE assessments SET status = $1, completed_at = NOW(), updated_at = NOW() WHERE id = $2',
      ['completed', assessmentId]
    );

    await addLog(assessmentId, 'info', 'Análisis completado exitosamente');
    console.log(`[${timestamp()}] [PROCESS] Analysis completed for assessment ${assessmentId}`);

  } catch (error) {
    console.error(`[${timestamp()}] [PROCESS] Fatal error processing assessment:`, error);
    await addLog(assessmentId, 'error', `Error crítico: ${error.message}`);
    await pool.query(
      'UPDATE assessments SET status = $1, updated_at = NOW() WHERE id = $2',
      ['failed', assessmentId]
    );
  }
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Self-hosted backend listening on port ${PORT}`);
});
